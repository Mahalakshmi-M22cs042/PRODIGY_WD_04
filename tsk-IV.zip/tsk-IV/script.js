window.addEventListener("scroll", () => {

const header = document.querySelector("header");

if(window.scrollY > 50){

header.style.background =
"rgba(15,23,42,0.95)";

}else{

header.style.background =
"rgba(0,0,0,0.3)";
}

});